package com.example.agrosuko.Model;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.agrosuko.DataStorage.DataModels;
import com.example.agrosuko.R;
import com.example.agrosuko.datos.Repositorio;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ActivityModificarSensor extends AppCompatActivity {

    private EditText editTextNombre;
    private EditText editTextDescripcion;
    private EditText editTextIdeal;
    private Spinner spinnerTipoSensor;
    private Button buttonGuardar;

    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference sensoresCollection = db.collection("sensores");

    private Repositorio repositorio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_sensor);

        // Inicializar vistas
        editTextNombre = findViewById(R.id.editTextNombreSensorModificar);
        editTextDescripcion = findViewById(R.id.editTextDescripcionSensorModificar);
        editTextIdeal = findViewById(R.id.editTextIdealSensorModificar);
        spinnerTipoSensor = findViewById(R.id.spinnerTipoSensorModificar);
        buttonGuardar = findViewById(R.id.buttonGuardarModificar);

        // Inicializar el repositorio
        repositorio = Repositorio.getInstance();

        // Obtener el nombre del sensor pasado a través del Intent
        String nombreSensor = getIntent().getStringExtra("sensorNombre");
        if (nombreSensor != null) {
            cargarSensor(nombreSensor);
        }

        // Cargar los tipos de sensores en el Spinner
        cargarTiposDeSensores();

        // Configurar el botón para guardar los cambios
        buttonGuardar.setOnClickListener(v -> guardarModificaciones());
    }

    private void cargarTiposDeSensores() {
        // Obtener los tipos de sensores desde el repositorio
        List<String> tipos = new ArrayList<>();
        for (DataModels.Tipo tipo : repositorio.getTipos()) {
            tipos.add(tipo.getNombre());  // Obtener solo el nombre de cada tipo
        }

        // Crear un adaptador para el Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, tipos);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Establecer el adaptador al Spinner
        spinnerTipoSensor.setAdapter(adapter);
    }

    private void cargarSensor(String nombre) {
        // Buscar el sensor por su nombre en Firestore
        sensoresCollection.whereEqualTo("sensor.nombre", nombre).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (!queryDocumentSnapshots.isEmpty()) {
                        for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                            // Aquí puedes cargar la información del sensor
                            String descripcion = document.getString("sensor.descripcion");
                            float ideal = document.getDouble("sensor.ideal").floatValue();

                            // Llenar los campos con los datos actuales
                            editTextNombre.setText(nombre);  // El nombre lo mostramos, pero ahora es editable
                            editTextDescripcion.setText(descripcion);
                            editTextIdeal.setText(String.valueOf(ideal));

                            // Mostrar mensaje Toast indicando que el sensor fue encontrado
                            Toast.makeText(this, "Sensor encontrado, puedes modificar los datos", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(this, "No se encontró el sensor con ese nombre", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Error al cargar sensor: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void guardarModificaciones() {
        String nombre = editTextNombre.getText().toString().trim();
        String descripcion = editTextDescripcion.getText().toString().trim();
        String idealString = editTextIdeal.getText().toString().trim();
        String tipoSensor = spinnerTipoSensor.getSelectedItem().toString();  // Obtener el tipo seleccionado

        // Validaciones
        if (nombre.isEmpty() || descripcion.isEmpty() || idealString.isEmpty()) {
            Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convertir el valor ideal a float
        float ideal = Float.parseFloat(idealString);

        // Crear los datos del sensor
        Map<String, Object> sensorData = new HashMap<>();
        sensorData.put("sensor.nombre", nombre);
        sensorData.put("sensor.descripcion", descripcion);
        sensorData.put("sensor.ideal", ideal);
        sensorData.put("sensor.tipo", tipoSensor);  // Guardar el tipo de sensor

        // Buscar el sensor en la base de datos para actualizarlo
        sensoresCollection.whereEqualTo("sensor.nombre", nombre).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (!queryDocumentSnapshots.isEmpty()) {
                        for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                            String documentId = document.getId();  // Obtener el ID del documento

                            // Ahora, actualizamos ese documento con los nuevos datos
                            sensoresCollection.document(documentId).update(sensorData)
                                    .addOnSuccessListener(aVoid -> {
                                        Toast.makeText(this, "Sensor modificado exitosamente", Toast.LENGTH_SHORT).show();
                                        finish(); // Cerrar la actividad
                                    })
                                    .addOnFailureListener(e -> Toast.makeText(this, "Error al modificar el sensor: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                        }
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Error al buscar el sensor: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
