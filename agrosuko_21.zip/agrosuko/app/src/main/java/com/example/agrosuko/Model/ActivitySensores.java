package com.example.agrosuko.Model;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.agrosuko.DataStorage.DataModels;
import com.example.agrosuko.DataStorage.DataStorage;
import com.example.agrosuko.R;
import com.example.agrosuko.datos.Repositorio;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ActivitySensores extends AppCompatActivity {

    private static final int MAX_DESCRIPTION_LENGTH = 30;
    private static final int MAX_NAME_LENGTH = 15;
    private Spinner tipoSensorSpinner;
    private Spinner ubicacionSensorSpinner;
    private EditText editTextNombre;
    private EditText editTextDescripcion;
    private EditText editTextIdeal;
    private Button buttonGuardar;
    private Button buttonBuscar;
    private Button buttonModificar; // Botón para modificar el sensor
    private Button buttonEliminar; // Botón para eliminar sensor

    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference sensoresCollection = db.collection("sensores");
    private CollectionReference ubicacionesCollection = db.collection("ubicaciones");

    private Repositorio repositorio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensores);

        // Inicializar vistas
        tipoSensorSpinner = findViewById(R.id.tipoSensorSpinner);
        ubicacionSensorSpinner = findViewById(R.id.ubicacionSensorSpinner);
        editTextNombre = findViewById(R.id.editTextNombreSensor);
        editTextDescripcion = findViewById(R.id.editTextDescripcionSensor);
        editTextIdeal = findViewById(R.id.editTextIdealSensor);
        buttonGuardar = findViewById(R.id.buttonGuardarSensor);
        buttonBuscar = findViewById(R.id.buttonBuscarSensor);
        buttonModificar = findViewById(R.id.btnModificarSensor); // Botón para modificar
        buttonEliminar = findViewById(R.id.buttonEliminarSensor); // Botón eliminar

        // Inicializar el repositorio
        repositorio = Repositorio.getInstance();

        // Cargar datos en los Spinners
        cargarDatosSpinner();

        // Configurar el botón buscar
        buttonBuscar.setOnClickListener(v -> buscarSensor());


        // Configurar los botones
        buttonGuardar.setOnClickListener(v -> guardarSensor());
        buttonModificar.setOnClickListener(v -> modificarSensor()); // Evento para modificar
        // Configurar el botón eliminar
        buttonEliminar.setOnClickListener(v -> eliminarSensor()); // Llamada a la función eliminar
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarDatosSpinner();
    }

    private void cargarDatosSpinner() {
        // Cargar los tipos de sensores en el Spinner
        List<String> tipos = new ArrayList<>();
        for (DataModels.Tipo tipo : DataStorage.tipos) {
            tipos.add(tipo.getNombre());
        }

        // Adaptador para el Spinner de tipos de sensores
        ArrayAdapter<String> tipoAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, tipos);
        tipoAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        tipoSensorSpinner.setAdapter(tipoAdapter);


        // Cargar las ubicaciones en el Spinner desde el repositorio
        List<String> ubicacionNombres = new ArrayList<>();

        // Primero, cargamos las ubicaciones predeterminadas del repositorio
        List<DataModels.Ubicacion> ubicacionesRepositorio = repositorio.getUbicaciones();
        for (DataModels.Ubicacion ubicacion : ubicacionesRepositorio) {
            ubicacionNombres.add(ubicacion.getNombre());
        }

        // Luego, tratamos de obtener ubicaciones desde Firestore si es posible
        ubicacionesCollection.get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    // Si Firestore tiene ubicaciones, las agregamos al listado sin ordenarlas
                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        String nombreUbicacion = document.getString("nombre");
                        if (nombreUbicacion != null && !ubicacionNombres.contains(nombreUbicacion)) {
                            ubicacionNombres.add(nombreUbicacion);
                            DataModels.Ubicacion ubicacion = new DataModels.Ubicacion(
                                    nombreUbicacion, // Solo nombre por ahora
                                    document.getString("descripcion") // Suponiendo que Firestore tiene un campo descripcion
                            );
                            DataStorage.ubicaciones.add(ubicacion);
                        }
                    }
                    // Actualizar el Spinner con los nombres de las ubicaciones
                    actualizarSpinnerUbicaciones(ubicacionNombres);
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error al cargar ubicaciones: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    // Si Firestore falla, usamos los datos de ejemplo
                    actualizarSpinnerUbicaciones(ubicacionNombres);
                });
    }

    private void actualizarSpinnerUbicaciones(List<String> ubicacionNombres) {
        ArrayAdapter<String> ubicacionAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, ubicacionNombres);
        ubicacionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ubicacionSensorSpinner.setAdapter(ubicacionAdapter);
    }

    private void guardarSensor() {
        String nombre = editTextNombre.getText().toString().trim();
        String descripcion = editTextDescripcion.getText().toString().trim();
        String idealString = editTextIdeal.getText().toString().trim();

        // Validaciones
        if (nombre.isEmpty()) {
            Toast.makeText(this, "Nombre del sensor es obligatorio", Toast.LENGTH_SHORT).show();
            return;
        }

        if (idealString.isEmpty()) {
            Toast.makeText(this, "Valor ideal es obligatorio", Toast.LENGTH_SHORT).show();
            return;
        }
        if (nombre.length() < 5 || nombre.length() > MAX_NAME_LENGTH) {
            Toast.makeText(this, "El nombre debe tener entre 5 y 15 caracteres", Toast.LENGTH_SHORT).show();
            return;
        }
        if (descripcion.length() > MAX_DESCRIPTION_LENGTH) {
            Toast.makeText(this, "La descripción debe tener un máximo de 30 caracteres", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convertir valor ideal a float
        float ideal = Float.parseFloat(idealString);

        // Obtener el tipo de sensor seleccionado
        String tipoSeleccionado = (String) tipoSensorSpinner.getSelectedItem();
        DataModels.Tipo tipoSensor = null;
        for (DataModels.Tipo tipo : DataStorage.tipos) {
            if (tipo.getNombre().equals(tipoSeleccionado)) {
                tipoSensor = tipo;
                break;
            }
        }

        // Obtener la ubicación seleccionada
        String ubicacionSeleccionada = (String) ubicacionSensorSpinner.getSelectedItem();
        DataModels.Ubicacion ubicacion = null;
        for (DataModels.Ubicacion u : DataStorage.ubicaciones) {
            if (u.getNombre().equals(ubicacionSeleccionada)) {
                ubicacion = u;
                break;
            }
        }

        // Obtener el siguiente ID disponible (comenzando desde 4)
        int nuevoId = DataModels.nextSensorId;  // Toma el valor actual de nextSensorId
        DataModels.nextSensorId++;  // Incrementa el contador para el siguiente sensor

        // Crear un nuevo sensor con el ID generado
        DataModels.Sensor nuevoSensor = new DataModels.Sensor(nuevoId, nombre, descripcion, ideal, tipoSensor, ubicacion);

        // Crear un mapa de los datos de la ubicación sin concatenación
        Map<String, Object> ubicacionMap = new HashMap<>();
        ubicacionMap.put("nombre", ubicacion.getNombre());
        ubicacionMap.put("descripcion", ubicacion.getDescripcion());

        // Crear un mapa de los datos del sensor sin concatenación
        Map<String, Object> sensorData = new HashMap<>();
        sensorData.put("nombre", nombre);
        sensorData.put("descripcion", descripcion);
        sensorData.put("ideal", ideal);
        sensorData.put("tipo", tipoSensor.getNombre());

        // Guardar la ubicación primero, luego el sensor dentro de ella
        Map<String, Object> sensorMap = new HashMap<>();
        sensorMap.put("ubicacion", ubicacionMap);  // Información de ubicación
        sensorMap.put("sensor", sensorData);      // Información del sensor

        // Guardar el sensor en Firestore con la estructura deseada
        sensoresCollection.add(sensorMap)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(ActivitySensores.this, "Sensor guardado exitosamente", Toast.LENGTH_SHORT).show();
                    // Limpiar campos
                    editTextNombre.getText().clear();
                    editTextDescripcion.getText().clear();
                    editTextIdeal.getText().clear();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(ActivitySensores.this, "Error al guardar sensor: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void abrirBuscarActivity() {
        // Lógica para abrir la actividad de búsqueda de sensores
        Intent intent = new Intent(this, ActivityBuscar.class);
        startActivity(intent);
    }

    private void modificarSensor() {
        // Obtener el nombre del sensor
        String nombre = editTextNombre.getText().toString().trim();

        if (nombre.isEmpty()) {
            Toast.makeText(this, "Por favor, ingresa el nombre del sensor para modificar.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Buscar el sensor por su nombre
        sensoresCollection.whereEqualTo("sensor.nombre", nombre).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (!queryDocumentSnapshots.isEmpty()) {
                        // Si se encuentra el sensor
                        Toast.makeText(ActivitySensores.this, "Sensor encontrado", Toast.LENGTH_SHORT).show();

                        // Aquí abrimos la actividad para modificar el sensor
                        Intent intent = new Intent(ActivitySensores.this, ActivityModificarSensor.class);
                        intent.putExtra("NOMBRE_SENSOR", nombre); // Pasamos el nombre del sensor como extra
                        startActivity(intent);
                    } else {
                        // Si no se encuentra el sensor
                        Toast.makeText(ActivitySensores.this, "Sensor no encontrado", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(ActivitySensores.this, "Error al buscar sensor: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    // Método para eliminar el sensor
    private void eliminarSensor() {
        String nombreBuscar = editTextNombre.getText().toString().trim();

        // Validación: si no se ha ingresado el nombre, mostramos un mensaje
        if (nombreBuscar.isEmpty()) {
            Toast.makeText(this, "Por favor ingrese el nombre del sensor a eliminar", Toast.LENGTH_SHORT).show();
            return;
        }

        // Buscar el sensor en Firestore por su nombre dentro del campo anidado "sensor"
        sensoresCollection.whereEqualTo("sensor.nombre", nombreBuscar).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (!queryDocumentSnapshots.isEmpty()) {
                        // Si encontramos el sensor, lo eliminamos
                        DocumentSnapshot document = queryDocumentSnapshots.getDocuments().get(0);
                        String documentId = document.getId(); // Obtener el ID del documento

                        // Eliminar el sensor de Firestore
                        sensoresCollection.document(documentId).delete()
                                .addOnSuccessListener(aVoid -> {
                                    Toast.makeText(this, "Sensor eliminado exitosamente", Toast.LENGTH_SHORT).show();
                                    // Limpiar los campos
                                    editTextNombre.getText().clear();
                                    editTextDescripcion.getText().clear();
                                    editTextIdeal.getText().clear();
                                })
                                .addOnFailureListener(e -> {
                                    Toast.makeText(this, "Error al eliminar sensor: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                });
                    } else {
                        // Si no encontramos el sensor
                        Toast.makeText(this, "Sensor no encontrado", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error al buscar el sensor: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }


    private void buscarSensor() {
        String nombreBuscar = editTextNombre.getText().toString().trim();

        // Validación: si no se ha ingresado el nombre, mostramos un mensaje
        if (nombreBuscar.isEmpty()) {
            Toast.makeText(this, "Por favor ingrese un nombre para buscar el sensor", Toast.LENGTH_SHORT).show();
            return;
        }

        // Buscar el sensor en Firestore por su nombre
        sensoresCollection.whereEqualTo("sensor.nombre", nombreBuscar).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (!queryDocumentSnapshots.isEmpty()) {
                        // Si encontramos el sensor, llenamos los campos de descripción y valor ideal
                        DocumentSnapshot document = queryDocumentSnapshots.getDocuments().get(0);

                        // Comprobar si la descripción y el valor ideal existen
                        String descripcion = document.getString("sensor.descripcion");
                        if (descripcion == null) {
                            descripcion = "";  // Definir un valor por defecto si no existe
                        }

                        Float valorIdeal = document.getDouble("sensor.ideal") != null ? document.getDouble("sensor.ideal").floatValue() : 0;

                        // Mostrar los resultados en los campos
                        editTextDescripcion.setText(descripcion);
                        editTextIdeal.setText(String.valueOf(valorIdeal));
                    } else {
                        // Si no encontramos el sensor
                        Toast.makeText(this, "Sensor no encontrado", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error al buscar sensor: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }
}