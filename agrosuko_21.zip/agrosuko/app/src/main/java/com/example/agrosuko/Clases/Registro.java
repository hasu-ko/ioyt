package com.example.agrosuko.Clases;

import java.util.Date;

public class Registro {
    private int id;
    private Date instante;
    private float lectura;
    private Sensor sensor;

    public Registro(int id, Date instante, float lectura, Sensor sensor) {
        this.id = id;
        this.instante = instante;
        this.lectura = lectura;
        this.sensor = sensor;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Date getInstante() { return instante; }
    public void setInstante(Date instante) { this.instante = instante; }

    public float getLectura() { return lectura; }
    public void setLectura(float lectura) { this.lectura = lectura; }

    public Sensor getSensor() { return sensor; }
    public void setSensor(Sensor sensor) { this.sensor = sensor; }
}
