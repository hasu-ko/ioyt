package com.example.agrosuko.datos;

import com.example.agrosuko.DataStorage.DataModels;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Repositorio {

    private static Repositorio instance = null;

    private List<DataModels.Tipo> tipos;
    private List<DataModels.Ubicacion> ubicaciones;
    private List<DataModels.Sensor> sensores;
    private List<DataModels.Registro> registros;
    private boolean datosDeMuestraCargados = false;

    // Contador para los ID de los sensores, comenzando desde 4
    private int idSensorActual = 3;  // El último ID usado es 3, así que el siguiente será 4.

    private Repositorio() {
        inicializarDatos();
    }

    public static Repositorio getInstance() {
        if (instance == null) {
            instance = new Repositorio();
        }
        return instance;
    }

    private void inicializarDatos() {
        tipos = new ArrayList<>();
        tipos.add(new DataModels.Tipo(1, "Temperatura"));
        tipos.add(new DataModels.Tipo(2, "Humedad"));

        ubicaciones = new ArrayList<>();
        sensores = new ArrayList<>();
        registros = new ArrayList<>();

        // Cargar datos de muestra solo una vez
        if (!datosDeMuestraCargados) {
            ubicaciones.add(new DataModels.Ubicacion(1, "Invernadero", "Área principal de cultivo"));
            ubicaciones.add(new DataModels.Ubicacion(2, "Campo Este", "Campo al este de la granja"));
            ubicaciones.add(new DataModels.Ubicacion(3, "Almacén", "Espacio de almacenamiento"));

            DataModels.Sensor sensor1 = new DataModels.Sensor(generarIdSensor(), "Sensor 1", "Sensor de temperatura", 25.0f, tipos.get(0), ubicaciones.get(0));
            DataModels.Sensor sensor2 = new DataModels.Sensor(generarIdSensor(), "Sensor 2", "Sensor de humedad", 60.0f, tipos.get(1), ubicaciones.get(1));

            sensores.add(sensor1);
            sensores.add(sensor2);

            registros.add(new DataModels.Registro(1, new Date(), 23.5f, sensor1));
            registros.add(new DataModels.Registro(2, new Date(), 58.0f, sensor2));

            datosDeMuestraCargados = true;
        }
    }

    // Método para generar un nuevo ID para el sensor
    private int generarIdSensor() {
        idSensorActual++;  // Incrementa el ID antes de devolverlo
        return idSensorActual;  // Devuelve el nuevo ID
    }

    public List<DataModels.Tipo> getTipos() {
        return tipos;
    }

    public List<DataModels.Ubicacion> getUbicaciones() {
        return ubicaciones;
    }

    public List<DataModels.Sensor> getSensores() {
        return sensores;
    }

    public List<DataModels.Registro> getRegistros() {
        return registros;
    }

    public void agregarUbicacion(DataModels.Ubicacion ubicacion) {
        ubicaciones.add(ubicacion);
    }

    public void agregarSensor(DataModels.Sensor sensor) {
        // Aquí se asegura de que el ID del nuevo sensor se genere correctamente
        sensor.setId(generarIdSensor());
        sensores.add(sensor);
    }
}
