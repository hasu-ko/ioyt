package com.example.agrosuko.Model;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.agrosuko.R;
import com.example.agrosuko.datos.Repositorio;
import com.example.agrosuko.DataStorage.DataModels;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ActivityUbicaciones extends AppCompatActivity {

    private EditText editTextNombre;
    private EditText editTextDescripcion;
    private Button buttonGuardar;
    private Spinner spinnerUbicaciones;
    private ArrayAdapter<String> ubicacionAdapter;
    private FirebaseFirestore db;
    private Repositorio repositorio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ubicaciones);

        // Inicializar Firebase Firestore
        db = FirebaseFirestore.getInstance();
        // Obtener la instancia del repositorio
        repositorio = Repositorio.getInstance();

        // Inicializar vistas
        editTextNombre = findViewById(R.id.editTextNombreUbicacion);
        editTextDescripcion = findViewById(R.id.editTextDescripcionUbicacion);
        buttonGuardar = findViewById(R.id.buttonGuardarUbicacion);
        spinnerUbicaciones = findViewById(R.id.ubicacionesSpinner);

        // Cargar los datos de ubicaciones (tanto de Firebase como de repositorio)
        cargarDatosUbicaciones();

        // Configurar el botón guardar
        buttonGuardar.setOnClickListener(v -> guardarUbicacion());

        // Hacer el campo nombre editable por defecto
        editTextNombre.setEnabled(true);
    }

    private void cargarDatosUbicaciones() {
        // Obtener las ubicaciones del repositorio
        List<DataModels.Ubicacion> ubicacionesRepositorio = repositorio.getUbicaciones();
        List<String> ubicacionNombres = new ArrayList<>();

        // Agregar las ubicaciones del repositorio al listado de nombres
        for (DataModels.Ubicacion ubicacion : ubicacionesRepositorio) {
            ubicacionNombres.add(ubicacion.getNombre());
        }

        // Recuperar datos de Firebase y combinarlos con los datos locales del repositorio
        db.collection("ubicaciones")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    // Si Firestore tiene ubicaciones, las agregamos al listado
                    for (var document : queryDocumentSnapshots.getDocuments()) {
                        String nombreUbicacion = document.getString("nombre");
                        if (nombreUbicacion != null && !ubicacionNombres.contains(nombreUbicacion)) {
                            ubicacionNombres.add(nombreUbicacion);
                        }
                    }
                    // Actualizar el Spinner con los nombres de las ubicaciones combinadas
                    actualizarSpinnerUbicaciones(ubicacionNombres);
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error al cargar ubicaciones desde Firestore: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    // Si Firestore falla, usamos solo los datos del repositorio
                    actualizarSpinnerUbicaciones(ubicacionNombres);
                });
    }

    private void guardarUbicacion() {
        String nombre = editTextNombre.getText().toString().trim();
        String descripcion = editTextDescripcion.getText().toString().trim();

        // Validación del nombre
        if (nombre.isEmpty()) {
            Toast.makeText(this, "Nombre de la ubicación es obligatorio", Toast.LENGTH_SHORT).show();
            return;
        }

        if (nombre.length() < 5 || nombre.length() > 15) {
            Toast.makeText(this, "El nombre debe tener entre 5 y 15 caracteres", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validación de la descripción
        if (descripcion.length() > 30) {
            Toast.makeText(this, "La descripción debe tener un máximo de 30 caracteres", Toast.LENGTH_SHORT).show();
            return;
        }

        // Crear un mapa para almacenar solo los campos necesarios (sin incluir ID)
        Map<String, Object> ubicacionData = new HashMap<>();
        ubicacionData.put("nombre", nombre);  // Solo los campos que queremos almacenar
        ubicacionData.put("descripcion", descripcion);

        // Guardar la ubicación en Firebase (Firestore maneja su propio ID)
        db.collection("ubicaciones")
                .add(ubicacionData)  // Guardamos solo los datos necesarios sin el ID
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(ActivityUbicaciones.this, "Ubicación guardada exitosamente", Toast.LENGTH_SHORT).show();
                    // Limpiar los campos de entrada
                    editTextNombre.getText().clear();
                    editTextDescripcion.getText().clear();
                    // Volver a cargar las ubicaciones desde Firebase y repositorio
                    cargarDatosUbicaciones();
                })
                .addOnFailureListener(e -> Toast.makeText(ActivityUbicaciones.this, "Error al guardar ubicación: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void actualizarSpinnerUbicaciones(List<String> ubicacionNombres) {
        // Agregar una opción por defecto (si no quieres permitir que el usuario deje el Spinner vacío)
        ubicacionNombres.add(0, "Seleccione una ubicación");

        // Actualizamos el adaptador del spinner con los nuevos datos combinados
        if (ubicacionAdapter == null) {
            ubicacionAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, ubicacionNombres);
            ubicacionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerUbicaciones.setAdapter(ubicacionAdapter);
        } else {
            ubicacionAdapter.clear();
            ubicacionAdapter.addAll(ubicacionNombres);
            ubicacionAdapter.notifyDataSetChanged();
        }

        // Set listener para que se cargue el nombre automáticamente y habilite/deshabilite el campo
        spinnerUbicaciones.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parentView, android.view.View selectedItemView, int position, long id) {
                if (position > 0) {  // Si se selecciona una ubicación válida (no "Seleccione una ubicación")
                    String selectedLocation = (String) parentView.getItemAtPosition(position);
                    editTextNombre.setText(selectedLocation); // Cargar el nombre del Spinner
                    editTextNombre.setEnabled(false);  // Deshabilitar la edición del campo nombre
                } else {
                    editTextNombre.setEnabled(true);  // Habilitar el campo nombre para que pueda escribirse
                    editTextNombre.getText().clear();  // Limpiar el campo de texto
                }
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parentView) {
                // Si no se selecciona nada, se habilita el campo de nombre
                editTextNombre.setEnabled(true);
            }
        });
    }
}
